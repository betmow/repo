"""dashlib - studies behind the BTC backtest dashboard.

Rules that keep every number causal:
  * an indicator value at bar t uses data up to the CLOSE of bar t only;
  * a trade decided at the close of bar t enters at the OPEN of bar t+1 and exits at the open of bar t+1+h;
  * results are split by the time of the signal bar into in-sample (IS) and out-of-sample (OOS);
  * samples are taken every h bars so that the h-bar trades never overlap (honest t-statistics).
"""
import numpy as np
import pandas as pd

TFS = ("1h", "4h", "12h", "1d", "1w")
TF_RULES = {"1h": "1h", "4h": "4h", "12h": "12h", "1d": "1D", "1w": "W-MON"}
TF_LEN = {"1h": pd.Timedelta(hours=1), "4h": pd.Timedelta(hours=4), "12h": pd.Timedelta(hours=12),
          "1d": pd.Timedelta(days=1), "1w": pd.Timedelta(days=7)}
TF_HOURS = {"1h": 1, "4h": 4, "12h": 12, "1d": 24, "1w": 168}

HORIZONS = (1, 3, 5, 10, 20)
RSI_PERIODS = (5, 7, 9, 14, 21, 30)
RSI_LO = (15, 20, 25, 30, 35, 40)
RSI_HI = (60, 65, 70, 75, 80, 85)
ADX_PERIODS = (7, 10, 14, 20, 28)
ADX_THR = (0, 15, 20, 25, 30, 35, 40)
DETECTORS = ("bb", "atr", "donch")
DET_PARAMS = {"bb": (10, 20, 30, 50), "atr": (7, 14, 21), "donch": (10, 20, 50)}
SQUEEZE_Q = (10, 20, 30)
RANK_WINDOW = 100          # a bar is "tight" if its width is in the lowest q% of the last 100 bars
MIN_BOX = 3                # a consolidation needs at least 3 bars before a close outside it counts as a breakout
MAX_DUR = 100              # consolidations longer than this are counted as censored, not as breakouts
EP_H = (1, 3, 5)           # follow-through horizons after a breakout (bars)
SPLITS = {"ALL": 0, "IS": 1, "OOS": 2}


def utc(x):
    t = pd.Timestamp(x)
    return t.tz_localize("UTC") if t.tzinfo is None else t.tz_convert("UTC")


# ----------------------------------------------------------------------------- bars
def make_bars(df1m, tfs=TFS):
    """Resample 1-minute data to each timeframe. Bars are labelled by open time. A first bar that starts before
    the data, and a last bar that is not finished, are dropped so no partial bar is ever used."""
    first, last = df1m.index[0], df1m.index[-1]
    agg = {"open": "first", "high": "max", "low": "min", "close": "last", "volume": "sum"}
    out = {}
    for tf in tfs:
        b = df1m.resample(TF_RULES[tf], closed="left", label="left").agg(agg)
        b = b[b["open"].notna()]
        if len(b) and b.index[0] < first:
            b = b.iloc[1:]
        if len(b) and b.index[-1] + TF_LEN[tf] > last + pd.Timedelta(minutes=1):
            b = b.iloc[:-1]
        out[tf] = b
    return out


# ----------------------------------------------------------------------------- indicators (Wilder, causal)
def rsi(close, n):
    d = close.diff()
    up = d.clip(lower=0.0)
    dn = (-d).clip(lower=0.0)
    au = up.ewm(alpha=1.0 / n, adjust=False, min_periods=n).mean()
    ad = dn.ewm(alpha=1.0 / n, adjust=False, min_periods=n).mean()
    out = 100.0 - 100.0 / (1.0 + au / ad)
    out = out.where(ad > 0, np.where(au > 0, 100.0, 50.0))
    return out.where(au.notna() & ad.notna())


def atr(df, n):
    pc = df["close"].shift(1)
    tr = pd.concat([df["high"] - df["low"], (df["high"] - pc).abs(), (df["low"] - pc).abs()], axis=1).max(axis=1)
    tr.iloc[0] = np.nan
    return tr.ewm(alpha=1.0 / n, adjust=False, min_periods=n).mean()


def adx_di(df, n):
    """Wilder ADX with +DI / -DI."""
    up = df["high"].diff()
    dn = -df["low"].diff()
    pdm = pd.Series(np.where((up > dn) & (up > 0), up, 0.0), index=df.index).where(up.notna())
    mdm = pd.Series(np.where((dn > up) & (dn > 0), dn, 0.0), index=df.index).where(up.notna())
    a = atr(df, n)
    pdi = 100.0 * pdm.ewm(alpha=1.0 / n, adjust=False, min_periods=n).mean() / a
    mdi = 100.0 * mdm.ewm(alpha=1.0 / n, adjust=False, min_periods=n).mean() / a
    dx = 100.0 * (pdi - mdi).abs() / (pdi + mdi)
    adx = dx.ewm(alpha=1.0 / n, adjust=False, min_periods=n).mean()
    return adx, pdi, mdi


def trailing_rank(x, window=RANK_WINDOW):
    """Fraction of the last `window` values (including the current one) that are <= the current value."""
    v = np.asarray(x, float)
    n = len(v)
    out = np.full(n, np.nan)
    if n < window:
        return out
    win = np.lib.stride_tricks.sliding_window_view(v, window)
    cur = win[:, -1][:, None]
    with np.errstate(invalid="ignore"):
        r = (win <= cur).mean(axis=1)
    r[np.isnan(win).any(axis=1)] = np.nan
    out[window - 1:] = r
    return out


def tightness(df, det, n):
    """Lower = tighter. bb: std/mean of closes (the Bollinger width without the 2k factor, which does not change a
    percentile rank); atr: ATR/close; donch: (n-bar high - n-bar low)/close."""
    c = df["close"]
    if det == "bb":
        return (c.rolling(n).std(ddof=0) / c.rolling(n).mean()).to_numpy()
    if det == "atr":
        return (atr(df, n) / c).to_numpy()
    if det == "donch":
        return ((df["high"].rolling(n).max() - df["low"].rolling(n).min()) / c).to_numpy()
    raise ValueError(det)


# ----------------------------------------------------------------------------- forward returns and splits
def fwd_returns(open_, h):
    """log(open[t+1+h] / open[t+1]) in bps, NaN where the exit would be beyond the data."""
    o = np.asarray(open_, float)
    n = len(o)
    out = np.full(n, np.nan)
    if n > h + 1:
        out[: n - h - 1] = np.log(o[1 + h:] / o[1: n - h]) * 1e4
    return out


def split_masks(index, analysis_start, oos_start):
    a, o = utc(analysis_start), utc(oos_start)
    ts = index
    ok = np.asarray(ts >= a)
    return {0: ok, 1: ok & np.asarray(ts < o), 2: np.asarray(ts >= o)}


def _stats(v):
    n = len(v)
    if n == 0:
        return 0, None, None
    m = float(v.mean())
    s = float(v.std(ddof=1)) if n > 1 else None
    return n, m, s


def stats3(mask, fwd, samp, sm):
    ok = mask & samp & np.isfinite(fwd)
    return [_stats(fwd[ok & sm[k]]) for k in (0, 1, 2)]


def _r(x, d=3):
    return None if x is None or (isinstance(x, float) and not np.isfinite(x)) else round(float(x), d)


# ----------------------------------------------------------------------------- studies 1 and 2: conditional forward returns
def study_rsi(bars, analysis_start, oos_start, periods=RSI_PERIODS, lo=RSI_LO, hi=RSI_HI, horizons=HORIZONS):
    rows = []
    for ti, tf in enumerate(TFS):
        b = bars.get(tf)
        if b is None or len(b) < 60:
            continue
        sm = split_masks(b.index, analysis_start, oos_start)
        idx = np.arange(len(b))
        fw = {h: fwd_returns(b["open"].to_numpy(), h) for h in horizons}
        sp = {h: (idx % h == 0) for h in horizons}
        allbars = np.ones(len(b), bool)
        for h in horizons:                      # baseline: every bar (the drift to compare against)
            for k, (n, m, s) in enumerate(stats3(allbars, fw[h], sp[h], sm)):
                rows.append([ti, 0, 2, 0, h, k, n, _r(m), _r(s)])
        for p in periods:
            r = rsi(b["close"], p).to_numpy()
            with np.errstate(invalid="ignore"):
                for thr in lo:
                    m_ = r < thr
                    for h in horizons:
                        for k, (n, m, s) in enumerate(stats3(m_, fw[h], sp[h], sm)):
                            rows.append([ti, p, 0, thr, h, k, n, _r(m), _r(s)])
                for thr in hi:
                    m_ = r > thr
                    for h in horizons:
                        for k, (n, m, s) in enumerate(stats3(m_, fw[h], sp[h], sm)):
                            rows.append([ti, p, 1, thr, h, k, n, _r(m), _r(s)])
    return {"cols": ["tf", "period", "cond", "thr", "h", "split", "n", "mean", "std"], "rows": rows,
            "periods": list(periods), "lo": list(lo), "hi": list(hi), "horizons": list(horizons)}


def study_adx(bars, analysis_start, oos_start, periods=ADX_PERIODS, thrs=ADX_THR, horizons=HORIZONS):
    """cond 0: ADX > thr and +DI > -DI (long side)   cond 1: ADX > thr and -DI > +DI (short side)
       cond 2: ADX <= thr and +DI > -DI              cond 3: ADX <= thr and -DI > +DI
       cond 4 (period 0): every bar = baseline drift. thr = 0 means 'DI direction only, no ADX filter'."""
    rows = []
    for ti, tf in enumerate(TFS):
        b = bars.get(tf)
        if b is None or len(b) < 60:
            continue
        sm = split_masks(b.index, analysis_start, oos_start)
        idx = np.arange(len(b))
        fw = {h: fwd_returns(b["open"].to_numpy(), h) for h in horizons}
        sp = {h: (idx % h == 0) for h in horizons}
        allbars = np.ones(len(b), bool)
        for h in horizons:
            for k, (n, m, s) in enumerate(stats3(allbars, fw[h], sp[h], sm)):
                rows.append([ti, 0, 4, 0, h, k, n, _r(m), _r(s)])
        for p in periods:
            a, pdi, mdi = adx_di(b, p)
            a, pdi, mdi = a.to_numpy(), pdi.to_numpy(), mdi.to_numpy()
            with np.errstate(invalid="ignore"):
                longd, shortd = pdi > mdi, mdi > pdi
                for thr in thrs:
                    hi_ = a > thr if thr > 0 else np.isfinite(a)
                    conds = [(0, hi_ & longd), (1, hi_ & shortd)]
                    if thr > 0:
                        lo_ = np.isfinite(a) & (a <= thr)
                        conds += [(2, lo_ & longd), (3, lo_ & shortd)]
                    for c, m_ in conds:
                        for h in horizons:
                            for k, (n, m, s) in enumerate(stats3(m_, fw[h], sp[h], sm)):
                                rows.append([ti, p, c, thr, h, k, n, _r(m), _r(s)])
    return {"cols": ["tf", "period", "cond", "thr", "h", "split", "n", "mean", "std"], "rows": rows,
            "periods": list(periods), "thrs": list(thrs), "horizons": list(horizons)}


# ----------------------------------------------------------------------------- study 3: consolidations and breakouts
def find_episodes(sq, high, low, close, open_, start_idx=0, min_box=MIN_BOX, max_dur=MAX_DUR):
    """Consolidation = from the first tight bar until a close leaves the box (running high/low of all bars since the
    start). Episodes never overlap. Returns (episodes, n_censored); each episode is
    (start, breakout_bar, direction, box_high, box_low)."""
    N = len(close)
    i, eps, cens = 0, [], 0
    while i < N:
        if i < start_idx or not sq[i]:
            i += 1
            continue
        s = i
        hi, lo = high[s], low[s]
        b = None
        for k in range(s + 1, min(N, s + max_dur + 1)):
            if k - s >= min_box and (close[k] > hi or close[k] < lo):
                b = k
                break
            hi = max(hi, high[k])
            lo = min(lo, low[k])
        if b is None:
            cens += 1
            i = s + max_dur + 1 if s + max_dur < N else N
            continue
        eps.append((s, b, 1 if close[b] > hi else -1, hi, lo))
        i = b + 1
    return eps, cens


def study_consolidation(bars, analysis_start, oos_start, detectors=DETECTORS, qs=SQUEEZE_Q):
    ep_rows, cfg_rows = [], []
    for ti, tf in enumerate(TFS):
        b = bars.get(tf)
        if b is None or len(b) < 160:
            continue
        N = len(b)
        o, h_, l_, c_ = (b[k].to_numpy(float) for k in ("open", "high", "low", "close"))
        vol = b["volume"]
        relvol = (vol / vol.shift(1).rolling(50, min_periods=30).median()).to_numpy()
        a14 = atr(b, 14).to_numpy()
        sm = split_masks(b.index, analysis_start, oos_start)
        start_idx = int(np.argmax(sm[0])) if sm[0].any() else N
        secs = ((b.index - pd.Timestamp("1970-01-01", tz="UTC")) // pd.Timedelta(seconds=1)).to_numpy()
        # forward range expansion: range of the next 10 bars in units of the current ATR(14)
        hi10 = b["high"].rolling(10).max().shift(-10).to_numpy()
        lo10 = b["low"].rolling(10).min().shift(-10).to_numpy()
        with np.errstate(invalid="ignore", divide="ignore"):
            exp10 = (hi10 - lo10) / a14
        samp = (np.arange(N) % 10 == 0) & np.isfinite(exp10)
        unc = [_stats(exp10[samp & sm[k]]) for k in (0, 1, 2)]
        for det in detectors:
            for prm in DET_PARAMS[det]:
                rk = trailing_rank(tightness(b, det, prm))
                for qi, q in enumerate(qs):
                    with np.errstate(invalid="ignore"):
                        sq = np.isfinite(rk) & (rk <= q / 100.0)
                    eps, cens = find_episodes(sq, h_, l_, c_, o, start_idx)
                    cond = [_stats(exp10[sq & samp & sm[k]]) for k in (0, 1, 2)]
                    n_ep = [0, 0, 0]
                    for (s, bk, d, bh, bl) in eps:
                        r = []
                        for hh in EP_H:
                            r.append(_r(d * np.log(o[bk + 1 + hh] / o[bk + 1]) * 1e4) if bk + 1 + hh < N else None)
                        if bk + 3 < N:
                            nxt = c_[bk + 1: bk + 4]
                            fb = int((nxt.min() <= bh) if d == 1 else (nxt.max() >= bl))
                        else:
                            fb = None
                        rvb = np.nanmean(relvol[s:bk]) if np.isfinite(relvol[s:bk]).any() else np.nan
                        ep_rows.append([ti, DETECTORS.index(det), prm, qi, int(secs[bk]), bk - s, d, *r, fb,
                                        _r(rvb), _r(relvol[bk]),
                                        _r((bh - bl) / a14[s]) if np.isfinite(a14[s]) and a14[s] > 0 else None])
                        n_ep[0] += 1
                        n_ep[1 + int(sm[2][bk])] += 1
                    for k in (0, 1, 2):
                        cfg_rows.append([ti, DETECTORS.index(det), prm, qi, k, n_ep[k], cens if k == 0 else None,
                                         cond[k][0], _r(cond[k][1]), _r(cond[k][2]),
                                         unc[k][0], _r(unc[k][1]), _r(unc[k][2])])
    return {"ep_cols": ["tf", "det", "param", "q", "t", "dur", "dir", "r1", "r3", "r5", "false", "rv_box", "rv_brk",
                        "box_atr"],
            "episodes": ep_rows,
            "cfg_cols": ["tf", "det", "param", "q", "split", "n_ep", "censored", "sq_n", "sq_mean", "sq_std",
                         "un_n", "un_mean", "un_std"],
            "configs": cfg_rows, "detectors": list(detectors), "det_params": {k: list(v) for k, v in DET_PARAMS.items()},
            "qs": list(qs), "ep_h": list(EP_H)}


# ----------------------------------------------------------------------------- everything
def build_all(df1m, analysis_start="2023-01-01", oos_start="2025-01-01", cost_bps=5.0, source="binance",
              progress=print):
    bars = make_bars(df1m)
    meta = {"tfs": list(TFS), "tf_hours": [TF_HOURS[t] for t in TFS], "analysis_start": str(analysis_start),
            "oos_start": str(oos_start), "cost_bps": cost_bps, "source": source,
            "synthetic": source == "synthetic", "data_start": str(df1m.index[0]), "data_end": str(df1m.index[-1]),
            "bars": {t: int(len(bars[t])) for t in TFS}, "generated": str(pd.Timestamp.now("UTC").floor("s")),
            "rank_window": RANK_WINDOW, "min_box": MIN_BOX, "max_dur": MAX_DUR}
    progress("RSI study ...")
    rs = study_rsi(bars, analysis_start, oos_start)
    progress("ADX/DI study ...")
    ad = study_adx(bars, analysis_start, oos_start)
    progress("Consolidation study ...")
    co = study_consolidation(bars, analysis_start, oos_start)
    meta["combos"] = {"rsi": len(RSI_PERIODS) * (len(RSI_LO) + len(RSI_HI)) * 2,
                      "adx": len(ADX_PERIODS) * (len(ADX_THR) - 1),
                      "consolidation": sum(len(v) for v in DET_PARAMS.values()) * len(SQUEEZE_Q)}   # per timeframe
    return {"meta": meta, "rsi": rs, "adx": ad, "con": co}
