"""Usage: python run_demo.py [prices.csv] [--controls N] [--agent]
CSV columns: timestamp(bar open), open, high, low, close, volume.  No CSV -> synthetic no-edge data."""
import os, sys, time
import pandas as pd
from zsys.data import load_csv, synthetic
from zsys.zones import build, ZoneConfig
from zsys.backtest import run, stats, Params, Risk
from zsys.research import control_test, bucket, validate_proposal

args = sys.argv[1:]
nctl = int(args[args.index("--controls") + 1]) if "--controls" in args else 10
path = next((a for a in args if a.endswith(".csv")), None)
df = load_csv(path) if path else synthetic(years=10)
cfg, p, risk = ZoneConfig(), Params(), Risk()
split = df.index[int(len(df) * 0.7)]
print(f"bars={len(df)}  {df.index[0].date()} -> {df.index[-1].date()}  OOS from {split.date()}")

t0 = time.time()
b = build(df, cfg)
tr, cv = run(df, b, p, risk)
print(f"zones={len(b.zones.lo)}  built+ran in {time.time()-t0:.1f}s")
print("ALL     ", {k: round(v, 3) for k, v in stats(tr, cv).items()})
if len(tr):
    is_tr = tr[pd.to_datetime(tr.entry_time) < split]
    oos_tr = tr[pd.to_datetime(tr.entry_time) >= split]
    print("IN-SAMPLE", {k: round(v, 3) for k, v in stats(is_tr, cv[cv.index < split]).items()})
    print("OOS      ", {k: round(v, 3) for k, v in stats(oos_tr, cv[cv.index >= split]).items()})
    print("\nExpectancy by confluence score:\n", bucket(tr, "score"))
    print("\nBy year:\n", bucket(tr, "year"))
print(f"\nControl test ({nctl} random-location runs)...")
ct = control_test(df, cfg, p, risk, n=nctl)
print({k: v for k, v in ct.items() if k != "control_exp_R_all"})
print("control exp_R:", ct["control_exp_R_all"])

if "--agent" in args:
    import anthropic
    from zsys.agent import ReviewAgent
    ag = ReviewAgent(anthropic.Anthropic(), tr[pd.to_datetime(tr.entry_time) < split], ct, p)
    print("\n--- Claude review ---\n", ag.run())
    for pr in ag.proposals:
        print("proposal:", pr["changes"], "->", validate_proposal(df, cfg, p, pr["changes"], risk, split))
