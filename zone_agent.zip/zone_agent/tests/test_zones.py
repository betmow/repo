import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np, pandas as pd
from zsys.data import synthetic
from zsys.zones import build, ZoneConfig, htf_candles, cluster, LAYERS
from zsys.backtest import run, Params, Risk


def _daily(n=40):
    idx = pd.date_range("2020-01-01", periods=n, freq="D")
    base = np.full(n, 100.0)
    return pd.DataFrame({"open": base, "high": base + 0.5, "low": base - 0.5, "close": base, "volume": 1.0}, index=idx)


def _gap_frame():
    df = _daily(40)
    c = df.columns.get_loc
    df.iloc[22, c("low")] = 102.0     # bar22 low above bar20 high (100.5) -> bullish gap 100.5..102.0
    df.iloc[22, c("high")] = 103.0
    df.iloc[22, c("close")] = 102.5
    df.iloc[23:, :4] = 104.0          # price stays away: gap untapped
    return df


def test_htf_drops_incomplete_and_close_time():
    df = synthetic(years=1, hours=4)[:500]
    for tf in "DWM":
        c = htf_candles(df, tf, pd.Timedelta(hours=4))
        assert (c.close_time <= df.index[-1] + pd.Timedelta(hours=4)).all()
        assert c.index[0] >= df.index[0]
    w = htf_candles(df, "W", pd.Timedelta(hours=4))
    assert (w.index.dayofweek == 0).all()


def test_fvg_bullish_detected_and_causal():
    df = _gap_frame()
    z = build(df, ZoneConfig(struct_tfs=(), fvg_tfs=("D",), ichi_tfs=())).zones
    k = [i for i in np.where(z.layer == LAYERS["fvg"])[0] if abs(z.lo[i] - 100.5) < 1e-9]
    assert k and abs(z.hi[k[0]] - 102.0) < 1e-9
    i = k[0]
    assert z.avail[i] == 23                      # known only after bar22 closes
    assert not z.active(22)[i] and z.active(25)[i]


def test_fvg_dies_when_tapped():
    df = _gap_frame()
    df.iloc[30, df.columns.get_loc("low")] = 101.0   # taps the gap
    z = build(df, ZoneConfig(struct_tfs=(), fvg_tfs=("D",), ichi_tfs=())).zones
    i = [i for i in np.where(z.layer == LAYERS["fvg"])[0] if abs(z.lo[i] - 100.5) < 1e-9][0]
    assert z.tested[i] == 30 and z.active(29)[i] and not z.active(30)[i]


def test_cluster_scores_distinct_layers():
    out = cluster(np.array([10.0, 10.1, 50.0]), np.array([10.2, 10.3, 50.1]),
                  np.array([0, 1, 2]), np.array([3.0, 2.0, 1.0]), tol=0.1)
    assert len(out) == 2 and out[0]["layers"] == 2 and out[0]["score"] == 5.0


def test_no_lookahead_truncation_invariance():
    """Zones active at bar t must be identical whether or not the future exists."""
    full = synthetic(years=4, seed=3)
    cfg = ZoneConfig(ichi_tfs=("W",))
    bf = build(full, cfg)
    sig = lambda b, tt: sorted((round(b.zones.lo[i], 6), round(b.zones.hi[i], 6), int(b.zones.layer[i]))
                               for i in np.where(b.zones.active(tt))[0])
    for t in (3000, 5000, 7000):
        bt = build(full.iloc[: t + 1], cfg)
        assert sig(bf, t) == sig(bt, t), f"zone set differs at t={t}"
        assert np.allclose(bf.avwap[t], bt.avwap[t], equal_nan=True)


def test_backtest_runs_and_is_sane():
    df = synthetic(years=4, seed=5)
    b = build(df, ZoneConfig(ichi_tfs=("W",)))
    tr, cv = run(df, b, Params(), Risk())
    assert cv.dropna().iloc[-1] > 0
    if len(tr):
        assert (tr.entry_time <= tr.exit_time).all()
        assert (tr.R >= -1.6).all()      # gaps may exceed -1R slightly, never wildly


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
            print("PASS", name)
