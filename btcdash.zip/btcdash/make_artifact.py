"""Make the hosted-viewer version of the dashboard: same page, wrapper tags removed (the host adds them),
demo data embedded. Real results are loaded in the browser with 'Load results file' (nothing is uploaded)."""
import json, os, re, sys
HERE = os.path.dirname(os.path.abspath(__file__))
src = open(os.path.join(HERE, "template.html"), encoding="utf-8").read()
data = open(sys.argv[1], encoding="utf-8").read().replace("</", "<\\/")
page = src.replace("/*DATA*/null", data)
title = re.search(r"<title>.*?</title>", page).group(0)
meta = '<meta name="claude:viewport-fit-sides" content="cover">'
style = re.search(r"<style>.*?</style>", page, re.S).group(0)
body = re.search(r"<body>(.*)</body>", page, re.S).group(1)
out = f"{title}\n{meta}\n{style}\n{body}"
open(sys.argv[2], "w", encoding="utf-8").write(out)
print("wrote", sys.argv[2], f"{len(out)/1e6:.1f} MB")
