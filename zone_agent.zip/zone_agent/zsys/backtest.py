"""Event-driven, causal backtester for the zone-confluence limit-order strategy.

Per bar t: (1) manage open position, (2) try to fill pending limit, (3) if idle,
decide on the CLOSE of t using only zones active at t, place limit for bars > t.
Conservative intrabar rules: stop beats target in the same bar; a stop is
checked on the fill bar; stop exits pay slippage; fees on both sides.
"""
from dataclasses import dataclass, asdict
import numpy as np
import pandas as pd
from .zones import Built, cluster


@dataclass
class Params:
    min_layers: int = 2
    min_score: float = 3.0
    max_dist_atr: float = 3.0
    cluster_tol_atr: float = 0.25
    max_zone_atr: float = 2.0   # reject merged zones wider than this (chained clusters)
    stop_atr: float = 0.5
    rr: float = 2.0
    expire_bars: int = 18
    fee_bps: float = 4.0
    slip_bps: float = 2.0


@dataclass
class Risk:
    """Hard limits live in code. No agent can modify these."""
    start_equity: float = 100_000.0
    risk_per_trade: float = 0.01
    max_leverage: float = 3.0
    max_dd_halt: float = 0.25
    daily_loss_limit: float = 0.03


def _candidates(b: Built, t, price, atr, p: Params):
    z = b.zones
    m = z.active(t)
    lo, hi, ly, w = z.lo[m], z.hi[m], z.layer[m], z.w[m]
    v = b.avwap[t]
    ok = np.isfinite(v) & (b.avwap_w > 0)
    if ok.any():
        lo = np.r_[lo, v[ok]]
        hi = np.r_[hi, v[ok]]
        ly = np.r_[ly, np.full(ok.sum(), 3)]
        w = np.r_[w, b.avwap_w[ok]]
    if len(lo) == 0:
        return []
    out = []
    for c in cluster(lo, hi, ly, w, p.cluster_tol_atr * atr):
        if c["layers"] < p.min_layers or c["score"] < p.min_score:
            continue
        if c["hi"] - c["lo"] > p.max_zone_atr * atr:
            continue
        if c["hi"] < price:
            side, dist = 1, (price - c["hi"]) / atr
        elif c["lo"] > price:
            side, dist = -1, (c["lo"] - price) / atr
        else:
            continue
        if dist <= p.max_dist_atr:
            out.append((c["score"], -dist, side, c))
    return out


def run(df: pd.DataFrame, b: Built, p: Params = Params(), risk: Risk = Risk()):
    o, h, l, c = (df[k].to_numpy() for k in ("open", "high", "low", "close"))
    idx, n, atr_d = df.index, len(df), b.atr_d
    eq, peak = risk.start_equity, risk.start_equity
    curve = np.full(n, np.nan)
    trades, pos, pend, halted = [], None, None, False
    day, day_eq0 = None, eq
    fee, slip = p.fee_bps / 1e4, p.slip_bps / 1e4

    def close_pos(t, px, reason):
        nonlocal eq, pos
        s, q = pos["side"], pos["qty"]
        pnl = s * (px - pos["entry"]) * q - fee * (px + pos["entry"]) * q
        trades.append({**{k: pos[k] for k in ("side", "entry", "stop", "target", "score", "layers")},
                       "entry_time": pos["t_in"], "exit_time": idx[t], "exit": px, "reason": reason,
                       "pnl": pnl, "R": pnl / pos["risk_cash"], "bars": t - pos["i_in"]})
        eq += pnl
        pos = None

    for t in range(n):
        d = idx[t].date()
        if d != day:
            day, day_eq0 = d, eq
        # 1) manage position
        if pos is not None and t > pos["i_in"]:
            s = pos["side"]
            if s * (o[t] - pos["stop"]) <= 0:
                close_pos(t, o[t], "stop_gap")
            elif s * ((l[t] if s == 1 else h[t]) - pos["stop"]) <= 0:
                close_pos(t, pos["stop"] * (1 - s * slip), "stop")
            elif s * (o[t] - pos["target"]) >= 0:
                close_pos(t, o[t], "target_gap")
            elif s * ((h[t] if s == 1 else l[t]) - pos["target"]) >= 0:
                close_pos(t, pos["target"], "target")
        # 2) pending fill
        if pend is not None and pos is None:
            if t >= pend["expire"]:
                pend = None
            else:
                s, lim = pend["side"], pend["limit"]
                if s * (lim - (l[t] if s == 1 else h[t])) >= 0:
                    fill = min(o[t], lim) if s == 1 else max(o[t], lim)
                    dist = s * (fill - pend["stop"])
                    if dist > 0:
                        q = min(eq * risk.risk_per_trade / dist, eq * risk.max_leverage / fill)
                        pos = {"side": s, "entry": fill, "stop": pend["stop"], "target": pend["target"],
                               "qty": q, "risk_cash": dist * q, "t_in": idx[t], "i_in": t,
                               "score": pend["score"], "layers": pend["layers"]}
                        pend = None
                        if s * ((l[t] if s == 1 else h[t]) - pos["stop"]) <= 0:
                            close_pos(t, pos["stop"] * (1 - s * slip), "stop")
                    else:
                        pend = None
        # equity & halts
        mtm = eq + (pos["side"] * (c[t] - pos["entry"]) * pos["qty"] if pos else 0.0)
        curve[t] = mtm
        peak = max(peak, mtm)
        if (peak - mtm) / peak > risk.max_dd_halt:
            halted = True
        # 3) decide
        if pos is None and pend is None and not halted and np.isfinite(atr_d[t]) and atr_d[t] > 0:
            if (eq - day_eq0) / day_eq0 > -risk.daily_loss_limit:
                cands = _candidates(b, t, c[t], atr_d[t], p)
                if cands:
                    score, _, side, cl = max(cands, key=lambda x: (x[0], x[1]))
                    atr = atr_d[t]
                    lim = cl["hi"] if side == 1 else cl["lo"]
                    stop = (cl["lo"] - p.stop_atr * atr) if side == 1 else (cl["hi"] + p.stop_atr * atr)
                    tgt = lim + side * p.rr * abs(lim - stop)
                    pend = {"side": side, "limit": lim, "stop": stop, "target": tgt, "score": score,
                            "layers": cl["layers"], "expire": t + 1 + p.expire_bars}
    tr = pd.DataFrame(trades)
    return tr, pd.Series(curve, index=idx)


def stats(tr: pd.DataFrame, curve: pd.Series) -> dict:
    if tr is None or len(tr) == 0:
        return {"n": 0, "win_rate": np.nan, "exp_R": np.nan, "profit_factor": np.nan, "return": 0.0, "max_dd": 0.0}
    w, ls = tr.pnl[tr.pnl > 0].sum(), -tr.pnl[tr.pnl < 0].sum()
    cv = curve.dropna()
    return {"n": int(len(tr)), "win_rate": float((tr.pnl > 0).mean()), "exp_R": float(tr.R.mean()),
            "profit_factor": float(w / ls) if ls > 0 else np.inf,
            "return": float(cv.iloc[-1] / cv.iloc[0] - 1),
            "max_dd": float(((cv.cummax() - cv) / cv.cummax()).max())}
