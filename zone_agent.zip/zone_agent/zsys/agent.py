"""Claude review agent: audits IN-SAMPLE trades and proposes parameter changes.

Safety design:
- It only sees trades before `split_ts` (out-of-sample is a sealed holdout).
- It can only propose whitelisted strategy params (see research.BOUNDS).
- Risk limits and execution are plain code it cannot touch.
- Every proposal is validated out-of-sample by code, not by the agent.
"""
import json
import pandas as pd
from .research import bucket, BOUNDS

SYSTEM = """You are a skeptical quantitative auditor for a zone-confluence trading strategy
(untested HTF closes + FVG + Ichimoku + anchored VWAP). You see IN-SAMPLE trades only.
Rules: (1) Distrust small samples (<30 trades per bucket). (2) Prefer few, simple, economically
motivated changes over curve-fitting. (3) Check the control test: if real results are not clearly
above random-location controls, say there is no demonstrated edge and propose nothing.
(4) Propose at most 3 changes via propose_params. (5) Be concise: findings, then proposals."""

TOOLS = [
    {"name": "trade_stats", "description": "In-sample performance grouped by a field.",
     "input_schema": {"type": "object", "properties": {"group_by": {"type": "string",
                      "enum": ["score", "layers", "side", "year", "reason"]}}, "required": ["group_by"]}},
    {"name": "worst_trades", "description": "The n worst in-sample trades by R.",
     "input_schema": {"type": "object", "properties": {"n": {"type": "integer"}}, "required": ["n"]}},
    {"name": "control_summary", "description": "Real vs random-location control results.",
     "input_schema": {"type": "object", "properties": {}}},
    {"name": "propose_params", "description": "Propose strategy parameter changes. Allowed keys: " + ", ".join(BOUNDS),
     "input_schema": {"type": "object", "properties": {"changes": {"type": "object"},
                      "rationale": {"type": "string"}}, "required": ["changes", "rationale"]}},
]


class ReviewAgent:
    def __init__(self, client, trades_is: pd.DataFrame, control: dict, params, model: str = "claude-sonnet-5-5"):
        self.client, self.model = client, model
        self.tr, self.control, self.params = trades_is, control, params
        self.proposals = []

    def _tool(self, name, inp):
        if name == "trade_stats":
            return bucket(self.tr, inp["group_by"]).to_string()
        if name == "worst_trades":
            cols = ["entry_time", "side", "score", "layers", "R", "reason"]
            return self.tr.nsmallest(int(inp["n"]), "R")[cols].to_string() if len(self.tr) else "no trades"
        if name == "control_summary":
            return json.dumps(self.control, default=float)
        if name == "propose_params":
            bad = [k for k in inp["changes"] if k not in BOUNDS]
            if bad:
                return f"rejected: parameters not allowed: {bad}"
            self.proposals.append(inp)
            return "recorded; will be validated out-of-sample by code"
        return "unknown tool"

    def run(self, max_turns: int = 8) -> str:
        msgs = [{"role": "user", "content": f"Current params: {self.params}. In-sample trades: {len(self.tr)}. Audit and propose."}]
        text = ""
        for _ in range(max_turns):
            r = self.client.messages.create(model=self.model, max_tokens=1500, system=SYSTEM,
                                            tools=TOOLS, messages=msgs)
            msgs.append({"role": "assistant", "content": r.content})
            text = "".join(b.text for b in r.content if b.type == "text") or text
            if r.stop_reason != "tool_use":
                break
            results = [{"type": "tool_result", "tool_use_id": b.id, "content": self._tool(b.name, b.input)}
                       for b in r.content if b.type == "tool_use"]
            msgs.append({"role": "user", "content": results})
        return text
