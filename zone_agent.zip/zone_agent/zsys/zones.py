"""Zone generators (structure, FVG, Ichimoku, anchored VWAP) + confluence clustering.

Causality contract: every zone carries
  avail  : first base-bar index at which it is knowable (higher-TF candle closed)
  end    : first base-bar index at which it expires (dynamic zones only)
  tested : first base-bar index at which price traded into it (static zones)
A zone is active at the close of bar t iff avail <= t < end and t < tested.
"""
from dataclasses import dataclass
import numpy as np
import pandas as pd

LAYERS = {"structure": 0, "fvg": 1, "ichi": 2, "avwap": 3}
TF_W = {"D": 1.0, "W": 2.0, "M": 3.0}


@dataclass
class ZoneConfig:
    struct_tfs: tuple = ("D", "W", "M")
    fvg_tfs: tuple = ("D", "W", "M")
    ichi_tfs: tuple = ("W", "M")
    pivot_n: int = 2            # candles each side to confirm a pivot close
    line_tol_atr: float = 0.15  # half-width of line-type zones, in HTF ATR
    min_fvg_atr: float = 0.15   # ignore tiny gaps
    avwap_min_bars: int = 12    # bars after anchor before AVWAP is trusted
    use_bands: bool = True      # include +-1 sigma AVWAP bands


def _period_end(ts, tf):
    if tf == "D":
        return ts + pd.Timedelta(days=1)
    if tf == "W":
        return ts + pd.Timedelta(days=7)
    return ts + pd.offsets.MonthBegin(1)


def htf_candles(df: pd.DataFrame, tf: str, delta) -> pd.DataFrame:
    """Higher-TF candles, COMPLETE ones only, with close_time and ATR(14)."""
    rule = {"D": "D", "W": "W-MON", "M": "MS"}[tf]
    o = df.resample(rule, closed="left", label="left").agg(
        {"open": "first", "high": "max", "low": "min", "close": "last", "volume": "sum"})
    o = o[o["open"].notna()]
    o = o[o.index >= df.index[0]]
    o["close_time"] = _period_end(o.index, tf)
    o = o[o["close_time"] <= df.index[-1] + delta].copy()
    pc = o["close"].shift(1)
    tr = pd.concat([o.high - o.low, (o.high - pc).abs(), (o.low - pc).abs()], axis=1).max(axis=1)
    o["atr"] = tr.rolling(14).mean()
    return o


@dataclass
class Zones:
    lo: np.ndarray
    hi: np.ndarray
    avail: np.ndarray
    end: np.ndarray
    tested: np.ndarray
    layer: np.ndarray
    w: np.ndarray
    tf: np.ndarray

    def active(self, t: int) -> np.ndarray:
        return (self.avail <= t) & (self.end > t) & (self.tested > t)


@dataclass
class Built:
    zones: Zones
    avwap: np.ndarray      # (n, 9) levels, NaN when untrusted
    avwap_w: np.ndarray    # (9,) weights
    atr_d: np.ndarray      # (n,) daily ATR known at each bar


def avwap_levels(df: pd.DataFrame, cfg: ZoneConfig):
    tp = (df.high + df.low + df.close) / 3
    v = df.volume.clip(lower=1e-9)
    keys = {"y": df.index.year, "q": df.index.year * 10 + df.index.quarter, "m": df.index.year * 100 + df.index.month}
    base_w = {"y": 3.0, "q": 2.0, "m": 1.0}
    cols, ws = [], []
    for name, key in keys.items():
        g = pd.Series(np.asarray(key), index=df.index)
        vv = v.groupby(g).cumsum()
        vw = (tp * v).groupby(g).cumsum() / vv
        sd = np.sqrt(np.maximum((tp * tp * v).groupby(g).cumsum() / vv - vw ** 2, 0))
        cnt = g.groupby(g).cumcount()
        bad = (cnt < cfg.avwap_min_bars).to_numpy()
        for s, wt in ((vw, base_w[name]), (vw + sd, base_w[name] * 0.5), (vw - sd, base_w[name] * 0.5)):
            a = s.to_numpy().copy()
            a[bad] = np.nan
            cols.append(a)
            ws.append(wt if (cfg.use_bands or wt == base_w[name]) else 0.0)
    return np.column_stack(cols), np.array(ws)


def build(df: pd.DataFrame, cfg: ZoneConfig = ZoneConfig(), jitter_seed=None, jitter_atr: float = 4.0) -> Built:
    """jitter_seed != None -> CONTROL run: every zone is shifted by a random
    offset (same timing, wrong location) to test whether location carries edge."""
    n = len(df)
    idx = df.index
    delta = idx[1] - idx[0]
    H, L = df.high.to_numpy(), df.low.to_numpy()
    INF = n + 10
    rng = np.random.default_rng(jitter_seed) if jitter_seed is not None else None
    rows = []

    def touch(lo, hi, start):
        if start >= n:
            return INF
        m = (H[start:] >= lo) & (L[start:] <= hi)
        k = int(m.argmax())
        return start + k if m[k] else INF

    def add(layer, tf, lo, hi, avail, end, scan_start, atr, static=True):
        if rng is not None:
            off = rng.uniform(-jitter_atr, jitter_atr) * atr
            lo, hi = lo + off, hi + off
        tested = touch(lo, hi, scan_start) if static else INF
        rows.append((lo, hi, avail, end, tested, LAYERS[layer], TF_W[tf], TF_W[tf]))

    tfs = set(cfg.struct_tfs) | set(cfg.fvg_tfs) | set(cfg.ichi_tfs) | {"D"}
    atr_d = None
    for tf in sorted(tfs, key=lambda x: TF_W[x]):
        c = htf_candles(df, tf, delta)
        if len(c) == 0:
            continue
        ct = idx.searchsorted(c["close_time"].to_numpy())
        atr = c["atr"].to_numpy()
        cl, ch, cw = c.close.to_numpy(), c.high.to_numpy(), c.low.to_numpy()
        if tf == "D":
            atr_d = pd.Series(atr, index=c["close_time"]).reindex(idx, method="ffill").to_numpy()
        k = cfg.pivot_n
        if tf in cfg.struct_tfs:
            for i in range(k, len(c) - k):
                if np.isnan(atr[i]):
                    continue
                win = cl[i - k:i + k + 1]
                if cl[i] == win.max() or cl[i] == win.min():
                    tol = cfg.line_tol_atr * atr[i]
                    add("structure", tf, cl[i] - tol, cl[i] + tol, ct[i + k], INF, ct[i], atr[i])
        if tf in cfg.fvg_tfs:
            for i in range(2, len(c)):
                if np.isnan(atr[i]):
                    continue
                if cw[i] > ch[i - 2] and cw[i] - ch[i - 2] >= cfg.min_fvg_atr * atr[i]:
                    add("fvg", tf, ch[i - 2], cw[i], ct[i], INF, ct[i], atr[i])
                elif ch[i] < cw[i - 2] and cw[i - 2] - ch[i] >= cfg.min_fvg_atr * atr[i]:
                    add("fvg", tf, ch[i], cw[i - 2], ct[i], INF, ct[i], atr[i])
        if tf in cfg.ichi_tfs:
            hh = lambda w: c.high.rolling(w).max()
            ll = lambda w: c.low.rolling(w).min()
            ten = (hh(9) + ll(9)) / 2
            kij = (hh(26) + ll(26)) / 2
            sa = ((ten + kij) / 2).to_numpy()
            sb = ((hh(52) + ll(52)) / 2).to_numpy()
            kij = kij.to_numpy()
            pe = _period_end(pd.DatetimeIndex(c["close_time"]), tf)
            ends = idx.searchsorted(pe.to_numpy())
            for i in range(len(c)):
                if ct[i] >= n or np.isnan(atr[i]):
                    continue
                lv = []
                if np.isfinite(kij[i]):
                    lv.append(kij[i])
                s = i + 1 - 26  # cloud of the period now forming = spans computed 26 candles ago
                if s >= 0 and np.isfinite(sa[s]) and np.isfinite(sb[s]):
                    lv += [sa[s], sb[s]]
                tol = cfg.line_tol_atr * atr[i]
                for x in lv:
                    add("ichi", tf, x - tol, x + tol, ct[i], ends[i], ct[i], atr[i], static=False)

    cols = list(zip(*rows)) if rows else [[]] * 8
    z = Zones(lo=np.array(cols[0], float), hi=np.array(cols[1], float), avail=np.array(cols[2], int),
              end=np.array(cols[3], int), tested=np.array(cols[4], int), layer=np.array(cols[5], int),
              w=np.array(cols[6], float), tf=np.array(cols[7], float))
    av, avw = avwap_levels(df, cfg)
    if rng is not None:
        av = av + rng.uniform(-jitter_atr, jitter_atr, av.shape[1])[None, :] * np.nan_to_num(atr_d)[:, None]
    return Built(z, av, avw, atr_d if atr_d is not None else np.full(n, np.nan))


def cluster(lo, hi, layer, w, tol):
    """Merge zones whose tolerance-expanded intervals overlap.
    Score = sum over DISTINCT layers of the strongest member weight."""
    out, cur = [], None
    for k in np.argsort(lo):
        xl, xh = lo[k] - tol, hi[k] + tol
        if cur is not None and xl <= cur["xhi"]:
            cur["lo"] = min(cur["lo"], lo[k])
            cur["hi"] = max(cur["hi"], hi[k])
            cur["xhi"] = max(cur["xhi"], xh)
            cur["lw"][layer[k]] = max(cur["lw"].get(layer[k], 0.0), w[k])
        else:
            if cur is not None:
                out.append(cur)
            cur = {"lo": lo[k], "hi": hi[k], "xhi": xh, "lw": {layer[k]: w[k]}}
    if cur is not None:
        out.append(cur)
    for c in out:
        c["score"] = float(sum(c["lw"].values()))
        c["layers"] = len(c["lw"])
    return out
