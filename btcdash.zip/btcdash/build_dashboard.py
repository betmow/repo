"""Build dashboard.html (and dashboard_data.json) from 1-minute BTC data.

    python build_dashboard.py                      # Binance public archive, cached in ./data
    python build_dashboard.py --source synthetic   # dry run on random data (no internet)
    python build_dashboard.py --source csv --csv my_data.csv
    python build_dashboard.py --serve              # then open the forwarded port 8000

Needs btcstudy.py (written by BTC_study.ipynb, or included in this folder) and dashlib.py next to this file.
"""
import argparse
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import btcstudy as bs        # noqa: E402
import dashlib as dl         # noqa: E402


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", default="binance", choices=["binance", "csv", "synthetic"])
    ap.add_argument("--symbol", default="BTCUSDT")
    ap.add_argument("--start", default="2022-07-01", help="first month to load; earlier than --analysis-start so indicators warm up")
    ap.add_argument("--analysis-start", default="2023-01-01")
    ap.add_argument("--oos-start", default="2025-01-01", help="signals from this date on are out-of-sample")
    ap.add_argument("--cost", type=float, default=5.0, help="default cost per side in bps (changeable in the page)")
    ap.add_argument("--cache", default=os.path.join(os.getcwd(), "data"))
    ap.add_argument("--csv", default="my_data.csv")
    ap.add_argument("--out", default="dashboard.html")
    ap.add_argument("--serve", action="store_true", help="serve the folder on port 8000 after building")
    a = ap.parse_args(argv)

    if a.source == "binance":
        df = bs.get_data("binance", symbol=a.symbol, interval="1m", start=a.start, end=None, cache_dir=a.cache)
    elif a.source == "csv":
        df = bs.get_data("csv", path=a.csv)
    else:
        df = bs.get_data("synthetic", start=a.start, days=1300)
    q = bs.quality_report(df)
    print({k: v for k, v in q.items() if k != "top_gaps"})
    if len(df) < 200_000:
        print("WARNING: very little data; most weekly/12h cells will be empty.")
    res = dl.build_all(df, a.analysis_start, a.oos_start, a.cost, source=a.source)
    res["meta"]["quality"] = {k: str(v) for k, v in q.items() if k != "top_gaps"}

    text = json.dumps(res, allow_nan=False, separators=(",", ":")).replace("</", "<\\/")
    tpl = open(os.path.join(HERE, "template.html"), encoding="utf-8").read()
    assert "/*DATA*/null" in tpl
    out = os.path.abspath(a.out)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    open(out, "w", encoding="utf-8").write(tpl.replace("/*DATA*/null", text))
    open(os.path.splitext(out)[0] + "_data.json", "w", encoding="utf-8").write(text)
    print(f"wrote {out} ({os.path.getsize(out) / 1e6:.1f} MB) and {os.path.splitext(out)[0]}_data.json")
    if a.serve:
        import functools
        import http.server
        d = os.path.dirname(out)
        h = functools.partial(http.server.SimpleHTTPRequestHandler, directory=d)
        print(f"Serving {d} on port 8000 - open /{os.path.basename(out)} (in Codespaces use the Ports tab or the pop-up)")
        http.server.ThreadingHTTPServer(("0.0.0.0", 8000), h).serve_forever()


if __name__ == "__main__":
    main()
