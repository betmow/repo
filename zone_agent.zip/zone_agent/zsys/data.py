import numpy as np
import pandas as pd

COLS = ["open", "high", "low", "close", "volume"]


def load_csv(path: str) -> pd.DataFrame:
    """CSV with columns: timestamp(bar OPEN time), open, high, low, close, volume."""
    df = pd.read_csv(path)
    df.columns = [c.lower() for c in df.columns]
    ts = "timestamp" if "timestamp" in df else df.columns[0]
    df[ts] = pd.to_datetime(df[ts])
    df = df.set_index(ts).sort_index()
    df = df[~df.index.duplicated()]
    if "volume" not in df:
        df["volume"] = 1.0
    return df[COLS].astype(float)


def synthetic(years: float = 10, hours: int = 4, seed: int = 0, start: str = "2014-01-01") -> pd.DataFrame:
    """Random-walk OHLCV with volatility regimes. Has NO edge by construction:
    a correct pipeline must find none here."""
    rng = np.random.default_rng(seed)
    n = int(years * 365 * 24 / hours)
    idx = pd.date_range(start, periods=n, freq=pd.Timedelta(hours=hours))
    ar = np.zeros(n)
    eps = rng.normal(0, 0.15, n)
    for i in range(1, n):
        ar[i] = 0.995 * ar[i - 1] + eps[i]
    sigma = 0.004 * np.exp(0.5 * np.clip(ar, -2, 2))
    close = 100 * np.exp(np.cumsum(sigma * rng.standard_normal(n)))
    open_ = np.r_[close[0], close[:-1]]
    hi = np.maximum(open_, close) * (1 + np.abs(rng.standard_normal(n)) * sigma * 0.6)
    lo = np.minimum(open_, close) * (1 - np.abs(rng.standard_normal(n)) * sigma * 0.6)
    vol = rng.lognormal(10, 0.5, n) * (1 + 20 * sigma)
    return pd.DataFrame({"open": open_, "high": hi, "low": lo, "close": close, "volume": vol}, index=idx)
