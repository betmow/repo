import sys, json, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, pandas as pd
import dashlib as dl
import btcstudy as bs

def mk_bars(n=3000, seed=0, freq="1h", start="2023-01-01", vol=0.004):
    rng = np.random.default_rng(seed)
    idx = pd.date_range(start, periods=n, freq=freq, tz="UTC")
    c = 20000 * np.exp(np.cumsum(rng.normal(0, vol, n)))
    o = np.r_[c[0], c[:-1]]
    hi = np.maximum(o, c) * (1 + np.abs(rng.normal(0, vol / 3, n)))
    lo = np.minimum(o, c) * (1 - np.abs(rng.normal(0, vol / 3, n)))
    return pd.DataFrame({"open": o, "high": hi, "low": lo, "close": c, "volume": rng.uniform(1, 5, n)}, index=idx)

def wilder(x, n):
    out = np.full(len(x), np.nan); s = None; cnt = 0
    for i, v in enumerate(x):
        if np.isnan(v): continue
        s = v if s is None else (1 - 1 / n) * s + (1 / n) * v
        cnt += 1
        if cnt >= n: out[i] = s
    return out

def test_rsi_known_answer():
    b = mk_bars(400)
    c = b["close"].to_numpy(); d = np.r_[np.nan, np.diff(c)]
    au = wilder(np.where(np.isnan(d), np.nan, np.maximum(d, 0)), 14); ad = wilder(np.where(np.isnan(d), np.nan, np.maximum(-d, 0)), 14)
    ref = 100 - 100 / (1 + au / ad)
    got = dl.rsi(b["close"], 14).to_numpy()
    assert np.allclose(got[20:], ref[20:], atol=1e-9) and np.isnan(got[:14]).all()
    assert ((got[14:] >= 0) & (got[14:] <= 100)).all()

def test_adx_known_answer():
    b = mk_bars(500, seed=1)
    h, l, c = (b[k].to_numpy() for k in ("high", "low", "close"))
    up = np.r_[np.nan, np.diff(h)]; dn = -np.r_[np.nan, np.diff(l)]
    pdm = np.where((up > dn) & (up > 0), up, 0.0); mdm = np.where((dn > up) & (dn > 0), dn, 0.0)
    pdm[0] = mdm[0] = np.nan
    pc = np.r_[np.nan, c[:-1]]
    tr = np.maximum.reduce([h - l, np.abs(h - pc), np.abs(l - pc)]); tr[0] = np.nan
    n = 14
    atr_ = wilder(tr, n); pdi = 100 * wilder(pdm, n) / atr_; mdi = 100 * wilder(mdm, n) / atr_
    dx = 100 * np.abs(pdi - mdi) / (pdi + mdi); adx = wilder(dx, n)
    a, p, m = dl.adx_di(b, n)
    assert np.allclose(a.to_numpy()[80:], adx[80:], atol=1e-8)
    assert np.allclose(p.to_numpy()[40:], pdi[40:], atol=1e-8) and np.allclose(m.to_numpy()[40:], mdi[40:], atol=1e-8)
    assert (a.dropna() >= 0).all() and (a.dropna() <= 100).all()

def test_causality_truncation():
    b = mk_bars(800, seed=2); k = 500
    for f in (lambda d: dl.rsi(d["close"], 14).to_numpy(), lambda d: dl.adx_di(d, 14)[0].to_numpy(),
              lambda d: dl.adx_di(d, 14)[1].to_numpy(),
              lambda d: dl.trailing_rank(dl.tightness(d, "bb", 20)),
              lambda d: dl.trailing_rank(dl.tightness(d, "atr", 14)),
              lambda d: dl.trailing_rank(dl.tightness(d, "donch", 20))):
        full, part = f(b), f(b.iloc[:k])
        assert np.allclose(full[:k], part, equal_nan=True), "indicator looks into the future"

def test_forward_alignment():
    o = np.array([100., 101, 103, 102, 110, 111, 120])
    f = dl.fwd_returns(o, 2)          # entry open[t+1], exit open[t+3]
    assert np.isclose(f[0], np.log(o[3] / o[1]) * 1e4) and np.isclose(f[3], np.log(o[6] / o[4]) * 1e4)
    assert np.isnan(f[4:]).all()

def test_trailing_rank():
    r = dl.trailing_rank(np.arange(1, 301, dtype=float), 100)
    assert np.isnan(r[:99]).all() and np.allclose(r[99:], 1.0)          # always the highest in its window
    r2 = dl.trailing_rank(-np.arange(1, 301, dtype=float), 100)
    assert np.allclose(r2[99:], 0.01)                                    # always the lowest: 1/100

def test_make_bars_drops_partial():
    idx = pd.date_range("2023-01-01 00:00", "2023-02-15 13:30", freq="1min", tz="UTC")   # Sunday start, ends mid-day
    df = pd.DataFrame({"open": 1.0, "high": 1.0, "low": 1.0, "close": 1.0, "volume": 1.0}, index=idx)
    bars = dl.make_bars(df)
    w = bars["1w"]
    assert w.index[0] == pd.Timestamp("2023-01-02", tz="UTC") and (w.index.dayofweek == 0).all()   # partial first week dropped, Monday labels
    assert w.index[-1] + pd.Timedelta(days=7) <= idx[-1] + pd.Timedelta(minutes=1)                 # last bar complete
    for tf in ("1h", "4h", "12h", "1d"):
        assert bars[tf].index[-1] + dl.TF_LEN[tf] <= idx[-1] + pd.Timedelta(minutes=1)
    assert bars["4h"].index[0] == pd.Timestamp("2023-01-01", tz="UTC")

def test_find_episodes():
    n = 40
    high = np.full(n, 101.0); low = np.full(n, 99.0); close = np.full(n, 100.0); open_ = close.copy()
    sq = np.zeros(n, bool); sq[5:12] = True
    close[15] = 105; high[15] = 106                       # breakout up at bar 15 (box = bars 5..14)
    eps, cens = dl.find_episodes(sq, high, low, close, open_)
    assert cens == 0 and eps[0][:3] == (5, 15, 1) and eps[0][3] == 101.0 and eps[0][4] == 99.0
    # a close outside the box inside the first MIN_BOX bars is not a breakout
    c2 = close.copy(); c2[15] = 100; c2[7] = 110
    eps2, _ = dl.find_episodes(sq, np.maximum(high, c2), low, c2, open_)
    assert eps2 == [] or eps2[0][1] > 5 + dl.MIN_BOX - 1
    # breakdown
    c3 = np.full(n, 100.0); c3[20] = 90
    eps3, _ = dl.find_episodes(sq, high, low, c3, open_)
    assert eps3[0][2] == -1 and eps3[0][1] == 20
    # censored when no breakout within MAX_DUR
    flat = np.full(300, 100.0)
    e4, cens4 = dl.find_episodes(np.r_[True, np.ones(299, bool)], flat + 1, flat - 1, flat, flat)
    assert e4 == [] and cens4 >= 1

def _manual_cell(b, rsi_p, thr, h, lo_cond, a0, o0, split):
    r = dl.rsi(b["close"], rsi_p).to_numpy(); o = b["open"].to_numpy(); ts = b.index
    vals = []
    for t in range(len(b)):
        if not np.isfinite(r[t]) or t % h != 0 or t + 1 + h >= len(b): continue
        if (r[t] < thr) if lo_cond else (r[t] > thr):
            if ts[t] < pd.Timestamp(a0, tz="UTC"): continue
            if split == 1 and not ts[t] < pd.Timestamp(o0, tz="UTC"): continue
            if split == 2 and not ts[t] >= pd.Timestamp(o0, tz="UTC"): continue
            vals.append(np.log(o[t + 1 + h] / o[t + 1]) * 1e4)
    v = np.array(vals); return len(v), (v.mean() if len(v) else None), (v.std(ddof=1) if len(v) > 1 else None)

def test_rsi_study_matches_independent_loop():
    b = mk_bars(3000, seed=3, freq="4h", start="2022-06-01")
    res = dl.study_rsi({"4h": b}, "2023-01-01", "2023-06-01", periods=(14,), lo=(40,), hi=(60,), horizons=(5,))
    for cond, lo_c in ((0, True), (1, False)):
        for split in (0, 1, 2):
            row = [r for r in res["rows"] if r[0] == 1 and r[1] == 14 and r[2] == cond and r[5] == split][0]
            n, m, s = _manual_cell(b, 14, 40 if lo_c else 60, 5, lo_c, "2023-01-01", "2023-06-01", split)
            assert row[6] == n and n > 5, (cond, split, row, n)
            assert abs(row[7] - m) < 1e-2 and abs(row[8] - s) < 1e-2, (cond, split, row, n, m, s)
    base = [r for r in res["rows"] if r[2] == 2 and r[5] == 1][0]
    assert base[6] > 100

def test_planted_effect_detected_and_null_clean():
    rng = np.random.default_rng(5); n = 6000; idx = pd.date_range("2022-10-01", periods=n, freq="1h", tz="UTC")
    c = np.empty(n); c[0] = 20000; g_u = g_d = 0.0; o = np.empty(n); o[0] = c[0]; pc = c[0]; rs = 50.0
    au = ad = None; hist = []
    for t in range(1, n):
        o[t] = c[t - 1]
        # RSI(14) of closes so far (Wilder, same seeding as dashlib)
        r = None
        if t >= 15:
            s = pd.Series(c[:t])
            r = dl.rsi(s, 14).iloc[-1]
        mu = 0.004 if (r is not None and r < 30) else 0.0
        c[t] = c[t - 1] * np.exp(rng.normal(mu, 0.004))
        if t > 3000 and t % 1 == 0 and False: pass
    hi = np.maximum(o, c) * 1.001; lo = np.minimum(o, c) * 0.999
    b = pd.DataFrame({"open": o, "high": hi, "low": lo, "close": c, "volume": 1.0}, index=idx)
    res = dl.study_rsi({"1h": b}, "2023-01-01", "2024-01-01", periods=(14,), lo=(30,), hi=(70,), horizons=(1,))
    rows = {(r[2], r[5]): r for r in res["rows"] if r[1] == 14}
    n1, m1, s1 = rows[(0, 0)][6:9]
    assert m1 > 20 and m1 / (s1 / np.sqrt(n1)) > 3, (n1, m1, s1)        # planted bounce detected
    n2, m2, s2 = rows[(1, 0)][6:9]
    assert abs(m2 / (s2 / np.sqrt(n2))) < 3, (n2, m2, s2)                # no effect above 70

def test_adx_study_cells_and_conditions():
    b = mk_bars(3000, seed=4, freq="4h", start="2022-06-01")
    res = dl.study_adx({"4h": b}, "2023-01-01", "2024-06-01", periods=(14,), thrs=(0, 25), horizons=(3,))
    a, pdi, mdi = (x.to_numpy() for x in dl.adx_di(b, 14)); o = b["open"].to_numpy(); ts = b.index
    def man(cond, thr):
        v = []
        for t in range(len(b)):
            if not np.isfinite(a[t]) or t % 3 or t + 4 >= len(b) or ts[t] < pd.Timestamp("2023-01-01", tz="UTC"): continue
            long_, short_ = pdi[t] > mdi[t], mdi[t] > pdi[t]
            ok = {0: (a[t] > thr if thr else True) and long_, 1: (a[t] > thr if thr else True) and short_,
                  2: a[t] <= thr and long_, 3: a[t] <= thr and short_}[cond]
            if ok: v.append(np.log(o[t + 4] / o[t + 1]) * 1e4)
        return len(v), np.mean(v)
    for cond, thr in ((0, 25), (1, 25), (2, 25), (3, 25), (0, 0), (1, 0)):
        row = [r for r in res["rows"] if r[2] == cond and r[3] == thr and r[5] == 0][0]
        n, m = man(cond, thr)
        assert row[6] == n and abs(row[7] - m) < 1e-2, (cond, thr, row, n, m)
    assert not [r for r in res["rows"] if r[2] in (2, 3) and r[3] == 0]

def test_episode_rows_match_manual():
    b = mk_bars(4000, seed=6, freq="4h", start="2022-06-01")
    res = dl.study_consolidation({"4h": b}, "2023-01-01", "2024-06-01", detectors=("bb",), qs=(20,))
    eps = [e for e in res["episodes"] if e[1] == 0 and e[2] == 20 and e[3] == 0]
    assert len(eps) > 20
    e = eps[0]
    t0 = pd.Timestamp(e[4], unit="s", tz="UTC"); bk = b.index.get_loc(t0); o = b["open"].to_numpy()
    assert abs(e[7] - e[6] * np.log(o[bk + 2] / o[bk + 1]) * 1e4) < 1e-2        # r1 uses entry at the open after the breakout bar
    assert e[5] >= dl.MIN_BOX and all(x[5] <= dl.MAX_DUR for x in eps)
    assert t0 >= pd.Timestamp("2023-01-01", tz="UTC")
    # episodes never overlap: starts are after previous breakouts
    ts = [x[4] for x in eps]; assert ts == sorted(ts)

def test_squeeze_predicts_range_expansion_when_planted():
    # volatility clusters: calm spells followed by large moves -> lift > 1 for a working detector
    rng = np.random.default_rng(8); n = 6000; idx = pd.date_range("2022-10-01", periods=n, freq="4h", tz="UTC")
    sig = np.empty(n); k = 0
    while k < n:
        L = int(rng.integers(30, 80)); sig[k:k + L] = 0.001 if (k // 1) % 2 == 0 else 0.001; k += L
    r = rng.normal(0, 0.006, n)
    calm = rng.random(n // 60 + 2)
    for j in range(0, n - 60, 60):          # 40 calm bars then 20 wild bars, repeating
        r[j:j + 40] = rng.normal(0, 0.0015, 40); r[j + 40:j + 60] = rng.normal(0, 0.012, 20)
    c = 20000 * np.exp(np.cumsum(r)); o = np.r_[c[0], c[:-1]]
    b = pd.DataFrame({"open": o, "high": np.maximum(o, c) * 1.0005, "low": np.minimum(o, c) * 0.9995, "close": c, "volume": 1.0}, index=idx)
    res = dl.study_consolidation({"4h": b}, "2023-01-01", "2030-01-01", detectors=("bb",), qs=(20,))
    lifts = {r[2]: r[8] / r[11] for r in res["configs"] if r[1] == 0 and r[4] == 0}
    assert lifts[30] > 1.3 and lifts[50] > 1.3, lifts          # a 40-calm/20-wild cycle is caught by the longer windows

def test_json_clean_and_full_build():
    df = bs.get_data("synthetic", start="2022-07-01", days=1000)
    res = dl.build_all(df, source="synthetic", progress=lambda *_: None)
    s = json.dumps(res, allow_nan=False)
    assert res["meta"]["bars"]["1w"] > 100 and len(res["rsi"]["rows"]) > 1000 and len(res["con"]["configs"]) == 360
    assert res["meta"]["synthetic"] is True

if __name__ == "__main__":
    import time, traceback
    fails = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            t = time.time()
            try:
                fn(); print(f"PASS {name} ({time.time()-t:.1f}s)")
            except Exception:
                fails += 1; print(f"FAIL {name}"); traceback.print_exc()
    sys.exit(1 if fails else 0)
