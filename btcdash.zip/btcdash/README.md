# BTC backtest dashboard

Put this folder next to your notebook (repo root), then from the repo root run:

    pip install numpy pandas pyarrow          # once
    python btcdash/build_dashboard.py         # downloads/reuses ./data, writes dashboard.html + dashboard_data.json
    python btcdash/build_dashboard.py --serve # same, then serves port 8000 (open the forwarded port, /dashboard.html)

Options: --start 2022-07-01 (load from; earlier than the analysis so indicators warm up), --analysis-start 2023-01-01,
--oos-start 2025-01-01, --cost 5, --source csv --csv file.csv, --source synthetic (dry run).

Tests: python btcdash/test_dashlib.py
