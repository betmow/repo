"""Edge validation: random-location control test, buckets, out-of-sample check."""
import numpy as np
import pandas as pd
from dataclasses import replace
from .zones import build, ZoneConfig
from .backtest import run, stats, Params, Risk

BOUNDS = {"min_layers": (1, 4), "min_score": (1.0, 10.0), "max_dist_atr": (0.5, 8.0),
          "cluster_tol_atr": (0.05, 1.0), "max_zone_atr": (0.5, 6.0), "stop_atr": (0.1, 2.0), "rr": (1.0, 5.0), "expire_bars": (3, 60)}


def control_test(df, cfg: ZoneConfig, p: Params, risk: Risk, n: int = 10, seed: int = 1000):
    """Same strategy and timing, but zone LOCATIONS randomised. If real results
    are not clearly above the control distribution, location carries no edge."""
    real_tr, real_cv = run(df, build(df, cfg), p, risk)
    real = stats(real_tr, real_cv)
    ctrl = []
    for i in range(n):
        tr, cv = run(df, build(df, cfg, jitter_seed=seed + i), p, risk)
        ctrl.append(stats(tr, cv))
    cexp = np.array([x["exp_R"] for x in ctrl], float)
    cexp = cexp[np.isfinite(cexp)]
    pct = float((cexp >= real["exp_R"]).mean()) if len(cexp) and np.isfinite(real["exp_R"]) else np.nan
    return {"real": real, "control_exp_R_mean": float(cexp.mean()) if len(cexp) else np.nan,
            "control_exp_R_std": float(cexp.std()) if len(cexp) else np.nan,
            "control_exp_R_all": [round(float(x), 3) for x in cexp],
            "p_value_vs_control": pct, "n_controls": len(cexp)}


def bucket(tr: pd.DataFrame, by: str) -> pd.DataFrame:
    if tr is None or len(tr) == 0:
        return pd.DataFrame()
    t = tr.copy()
    if by == "year":
        t["k"] = pd.to_datetime(t.entry_time).dt.year
    elif by == "score":
        t["k"] = t.score
    else:
        t["k"] = t[by]
    g = t.groupby("k")
    return pd.DataFrame({"n": g.size(), "win_rate": g.pnl.apply(lambda x: (x > 0).mean()), "exp_R": g.R.mean()}).round(3)


def validate_proposal(df, cfg, base: Params, changes: dict, risk: Risk, split_ts, min_trades: int = 20):
    """Accept a proposed param change only if it improves OUT-OF-SAMPLE expectancy
    (trades after split_ts) with enough trades. Risk limits cannot be changed."""
    for k, v in changes.items():
        if k not in BOUNDS:
            return {"accepted": False, "reason": f"parameter '{k}' not allowed"}
        lo, hi = BOUNDS[k]
        if not (lo <= v <= hi):
            return {"accepted": False, "reason": f"{k}={v} outside bounds {lo}-{hi}"}
    b = build(df, cfg)
    out = {}
    for name, p in (("base", base), ("new", replace(base, **changes))):
        tr, cv = run(df, b, p, risk)
        oos = tr[pd.to_datetime(tr.entry_time) >= pd.Timestamp(split_ts)] if len(tr) else tr
        out[name] = stats(oos, cv[cv.index >= pd.Timestamp(split_ts)])
    ok = (out["new"]["n"] >= min_trades and np.isfinite(out["new"]["exp_R"])
          and out["new"]["exp_R"] > out["base"]["exp_R"])
    return {"accepted": bool(ok), "oos_base": out["base"], "oos_new": out["new"]}
